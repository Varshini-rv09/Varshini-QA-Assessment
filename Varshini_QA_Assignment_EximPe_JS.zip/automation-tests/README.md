# OrangeHRM QA Assignment

## Setup
npm install
npx playwright install

## Run Tests
npx playwright test

## View HTML Report
npx playwright show-report
